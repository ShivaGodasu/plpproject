import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Product } from './product';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  product:Product[];
private userId=new BehaviorSubject<number>(0);
currentUser=this.userId.asObservable();

  constructor(private _httpService:HttpClient) { }

baseUrl:string="http://localhost:8090/products/";

getProducts(type:string)
{

  return this._httpService.get(`${this.baseUrl}`+type);
}
getProductById(id:number)
{
 
  return this._httpService.get("//localhost:8090/ProductById/"+id);
}
setUser(userid:number)
{
  this.userId.next(userid);
}

getFeedbackById(id:number){
  return this._httpService.get("//localhost:8090/FeedbackById/"+id);
}

getProductListByRange(low:number,high:number,type:string):Observable<any> {
  return this._httpService.get("http://localhost:8090/get/"+low+"/"+high+"/"+type); 
}

getAllProdcutsList():Observable<any> {
  return this._httpService.get("http://localhost:8090/getAll/");   
}

addtoWishList(productId,userId):Observable<any> {
  let body=JSON.stringify(productId);
  let headers=new  HttpHeaders({'Content-Type':'application/json'});
  return this._httpService.post("http://localhost:8090/addtoWishList/"+userId+"/",body,{headers: headers});   
}

getWishlist(userId):Observable<any> {
  return this._httpService.get("//localhost:8090/getWishList/"+userId);
}

addtoCart(productId,userId1):Observable<any> {
  let body=JSON.stringify(productId);
  let headers=new  HttpHeaders({'Content-Type':'application/json'});
  return this._httpService.post("http://localhost:8090/addtoCart/"+userId1+"/",body,{headers: headers});   
}

}